﻿/*
*Bank_Simulation.cpp
*/
#include <stdio.h>
#include <time.h>
#include <stdlib.h>
typedef struct {
int OccurTime;
int NType;
}Event,ElemType;
typedef struct LNode{
ElemType data;
struct LNode *next;
}LNode, *LinkList;
int CreateList( LinkList &L,int n );
int DestroyList( LinkList &L );
int Traverse( LinkList L );
int GetElem( LinkList L, int i, ElemType &e );
int ListInsert( LinkList &L, int i, ElemType e );
int ListDelete( LinkList &L, int i, ElemType &e );
int ListEmpty( LinkList L );
int OrderInsert( LinkList &L, ElemType e );
typedef struct{
int ArrivalTime;
int Duration;
}QElemType;
typedef struct QNode{
QElemType     data;
struct QNode *next;
}QNode,*QueuePtr;
typedef struct {
QueuePtr front;
QueuePtr rear;
}LinkQueue;
int InitQueue( LinkQueue &Q );
int EnQueue( LinkQueue &Q, QElemType e );
int DeQueue( LinkQueue &Q, QElemType &e );
int DestoryQueue( LinkQueue &Q );
int ClearQueue( LinkQueue &Q );
int QueueEmpty( LinkQueue Q );
int GetHead( LinkQueue Q, QElemType &e );
int QueueLength( LinkQueue Q );
int QueueTraverse( LinkQueue Q );
typedef LinkList EventList;
int cmp( Event a, Event b ); 
int Minmum( LinkQueue *q );
int Random( int &durtime, int &intertime );
int OpenForDay( int &TotalTime, int &CustomerNum, EventList &ev, LinkQueue *q , Event &en );
int CustomerArrived( int &CustomerNum, EventList &ev, LinkQueue *q , Event &en ,int CloseTime, int &durtime, int &intertime );
int CustomerDepartured( int &TotalTime, EventList &ev, LinkQueue *q , Event &en, QElemType &customer, int &durtime, int &intertime );
int Bank_Simulation( int CloseTime );
int main( ) 
{   
int t = 60;
  Bank_Simulation( t );
return 1;
}
int CreateList(LinkList &L,int n ) {
  L = ( LinkList ) malloc( sizeof( LNode ) );
L->next = NULL;
LinkList p;
if ( n >= 1 ) {
printf( "Input %d element:\n", n );
for ( int i = n; i > 0; i -- ) {
p = ( LinkList ) malloc( sizeof( LNode ) );
  scanf( "%d %d",&p->data.OccurTime, &p->data.NType );
p->next = L->next; L->next = p;
}
printf( "Input complicated\n");
}
  return 1;
}
int DestroyList(LinkList &L ) {
LinkList p = L->next;
while ( p ) {
L->next = p->next;
free( p );
p= L->next;
}
L->next = NULL;
  return 1;
}
int ListEmpty( LinkList L )
{
if ( L->next == NULL )
return 1;
else
return 0;
}
int GetElem(LinkList L, int i, ElemType &e )
{ 
LinkList p = L->next; int j = 1;
while( p && j<i ) {
p = p->next; ++ j;
}
if ( !p || j>i )  return 0;
  e = p->data;
return 1; 
}
int Traverse(LinkList L ) {
LinkList p = L->next;
if ( p != NULL )
printf( "The element in the List:\n");
while( p != NULL ) {
  printf("OccurTime:NType[%d,%d] ",p->data.OccurTime, p->data.NType );
p = p->next;
}
printf( "\n" );
return 1;
}
int ListInsert(LinkList &L, int i, ElemType e )
{   LinkList p = L;
int j = 1;
while ( p && j < i ) {
p = p->next; ++ j;
}
if ( !p || j > i ) return 0;
  LinkList s =( LinkList ) malloc( sizeof( LNode ) );
  s->data.NType = e.NType;
s->data.OccurTime = e.OccurTime;
s->next = p->next; p->next = s;
return 1;
}
int ListDelete(LinkList &L, int i, ElemType &e )
{   LinkList p = L;
int j = 1;
while ( p->next && j < i ) {
p = p->next; ++ j;
}
if ( !p->next || j > i ) return 0;
  LinkList q = p->next;  p->next = q->next;
e.NType = q->data.NType; 
e.OccurTime = q->data.OccurTime;
free( q );
return 1;
} 
int InitQueue( LinkQueue &Q )
{
  Q.front = Q.rear = ( QueuePtr ) malloc ( sizeof( QNode ) );
if ( !Q.front ) exit( 0 );
Q.front->next = NULL;
return 1;
}
int DestoryQueue( LinkQueue &Q )
{   
while ( Q.front )
{
Q.rear = Q.front->next;
free( Q.front );
Q.front = Q.rear;
}
return 1;
}
int ClearQueue( LinkQueue &Q )
{   QueuePtr p = Q.front->next;
while ( p )
{
Q.rear = p->next ;
free( p );
p = Q.rear;
}
Q.rear = Q.front;
Q.front->next = NULL;
return 1;
}
int QueueEmpty( LinkQueue Q )
{   
if ( Q.rear == Q.front )
  return 1;
  else
return 0;
}
int GetHead( LinkQueue Q, QElemType &e )
{
e.ArrivalTime = Q.front->next->data.ArrivalTime;
  e.Duration = Q.front->next->data.Duration;
return 1;
}
int EnQueue( LinkQueue &Q, QElemType e )
{
QueuePtr p = ( QueuePtr ) malloc ( sizeof( QNode ) );
if ( !p ) exit( 0 );
p->data.ArrivalTime = e.ArrivalTime; 
p->data.Duration = e.Duration; 
p->next = NULL;
Q.rear->next = p;
Q.rear = p;
return 1;
}
int DeQueue( LinkQueue &Q, QElemType &e )
{
if ( Q.front == Q.rear ) return 0; // It's empty!
  QueuePtr p = Q.front->next;
e.ArrivalTime = p->data.ArrivalTime;
e.Duration = p->data.Duration;
Q.front->next = p->next;
if ( p == Q.rear ) // p->next = NULL;
  Q.rear = Q.front; 
free( p );
return 1;
}
int QueueTraverse( LinkQueue Q )
{
QueuePtr p = Q.front->next;
while ( p )
{
printf( "ArrivalTime:Duration[%d,%d] ", p->data.ArrivalTime, p->data.Duration );
p = p->next;
}
printf( "\n" );
return 1;
}
int QueueLength( LinkQueue Q )
{
int length = 0;
  QueuePtr p = Q.front->next;
while ( p )
{
length ++;
p = p->next;
}
return length;
}
int cmp( Event a, Event b )
{   // 事件a发生在事件b之前
if ( a.OccurTime <= b.OccurTime )
return 1;
else
return 0;
}
int Minmum( LinkQueue *q )
{
  int min[5];
for ( int i = 1; i <= 4; i ++ ) {
min[ i ] = QueueLength( q[ i ] );
}
for ( i = 1; i <= 3; i ++ ) 
min[ i+1 ] = ( min[ i ] <= min[i + 1] ) ? min[ i ]: min[ i + 1 ]; 
return min[ 4 ];
}
int Random( int &durtime, int &intertime )
{ 
//struct tm *newtime;
time_t long_time;
  time( &long_time );               /* Get time as long integer. */
srand( long_time  );
durtime = rand( ) % 30;
intertime = rand( ) % 5;
printf( "durtime:intertime:[%d,%d]\n", durtime, intertime);
return 1;
}
int OrderInsert( LinkList &L, ElemType e )
{
LinkList p = L; // 指向头节点
  // p->next->data 第一节点的事件
  if ( p->next != NULL )
while ( cmp( e, p->next->data ) == 1  && p->next != NULL ) { // 直到当前事件发生于事件队列某节点之后
  p = p->next; 
// 指向某节点的指针后移
}
  if ( !p ) {
  printf( "OrderInsert Failed!\n");
return 0;
}
  LinkList s =( LinkList ) malloc( sizeof( LNode ) );
  s->data.NType = e.NType;
s->data.OccurTime = e.OccurTime;
s->next = p->next; p->next = s;
return 1;
}
int OpenForDay( int &TotalTime, int &CustomerNum, EventList &ev, LinkQueue *q , Event &en )
{
TotalTime = 0; 
CustomerNum = 0;                 // 初始化累计时间和客户数为0
en.NType = 0;
en.OccurTime = 0;                // 设定第一个客户到达事件
  CreateList( ev, 0 );             // 初始化事件链表为空表
OrderInsert( ev, en );           // 插入事件表
for ( int i = 0; i <= 4; i ++ )  
  InitQueue( q[ i ] );       // 置空队列
/*Traverse( ev );*/
return 1;
}
int CustomerArrived( int &CustomerNum, EventList &ev, LinkQueue *q , Event &en ,int CloseTime, int &durtime, int &intertime) 
{
Event x;
QElemType e;
++ CustomerNum;
//printf( "The Time%d\n",CustomerNum);
Random( durtime, intertime );    // 生成随机数
int t = en.OccurTime + intertime;// 下一客户到达时间
if ( t < CloseTime )             // 银行尚未关门，插入事件表
{
x.OccurTime = t;
x.NType = 0;
OrderInsert( ev, x );
}
int i = Minmum( q );             // 求长度最短队列编号
//printf( "The Time%d\n",i);
e.ArrivalTime = en.OccurTime;
e.Duration = durtime;
EnQueue( q[ i ], e );

if ( QueueLength( q[ i ] ) == 1 )
{
x.OccurTime = en.OccurTime + durtime;
x.NType = i;
  OrderInsert( ev, x );        // 设定第i队列的一个离开事件并插入事件表
}
return 1;
}
int CustomerDepartured( int &TotalTime, EventList &ev, LinkQueue *q , Event &en, QElemType &customer, int &durtime, int &intertime )
{
  printf( "The Time\n");
int i = en.NType;
Event x;
  DeQueue( q[ i ] , customer );                  // 从第i队列删除排头客户信息
TotalTime = TotalTime + en.OccurTime - customer.ArrivalTime;  
  //printf( "The Time%d\n",TotalTime);
// 累计用户逗留时间，即离开事件发生时间减到达时间
  if ( !QueueEmpty( q[ i ] ) )                   // 队列不为空
{ 
GetHead( q[ i ], customer );                    // 取出下一位客户，保存在当前服务客户信息中
x.OccurTime = en.OccurTime + customer.Duration; // 设定第i队列的一个离开事件并插入事件列表
x.NType = i; 
OrderInsert( ev, x );
}
return 1;
}
int Bank_Simulation( int CloseTime )
{
  EventList ev;              // 事件表
  Event en;                  // 事件
LinkQueue q[ 5 ];          // 四个客户队列
QElemType customer;        // 客户记录
int TotalTime,CustomerNum; // 逗留时间，客户数
  int durtime = 0; int intertime = 0;
OpenForDay( TotalTime, CustomerNum, ev, q , en );  // 初始化
while( !ListEmpty( ev ) )  // 事件表不空
{   
/*
  *DelFirst( GetHead( ev ) , p );
  *en = GetCurElem( p );
*/
ListDelete( ev, 1, en ); // GetHead_EventList
if ( en.NType == 0 ) // 处理客户到达事件
CustomerArrived( CustomerNum, ev, q , en, CloseTime, durtime , intertime );
else                 // 处理客户离开事件
CustomerDepartured( TotalTime, ev, q , en, customer, durtime , intertime );
}
for ( int i = 0; i <= 4; i ++ )
  DestoryQueue( q[ i ] );
DestroyList( ev );       // 回收资源
printf( "The TotalTime is %f\n", (float)TotalTime);
printf( "The CustomerNum is %d\n", CustomerNum );
//printf( "The Average Time is %f\n", (float)TotalTime / CustomerNum );
//printf( "The Time\n");
  return 1;
}