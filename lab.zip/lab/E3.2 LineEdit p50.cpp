﻿#include <stdio.h>
#include <stdlib.h>
#define STACK_INIT_SIZE 5
#define STACKINCREAMENT 5
typedef struct {
char *base;
char *top;
int stacksize;
}SqStack;
int InitStack( SqStack &s );
int DestoryStack( SqStack &s );
int ClearStack( SqStack &s );
int StackEmpty( SqStack s );
int StackLength( SqStack s );
int StackTraverse( SqStack s );
int GetTop( SqStack s, char &e );
int Push( SqStack &s, char e );
int Pop( SqStack &s, char &e );
int LineEdit( SqStack &s, char &e );
int main( )
{   
SqStack s;
char e = '0';
  LineEdit( s, e );
return 1;
}
int InitStack( SqStack &s )
{   s.base = ( char * )malloc( STACK_INIT_SIZE*sizeof( char ) );
  if ( !s.base ) exit( 0 );
else
s.top = s.base;
s.stacksize = STACK_INIT_SIZE;
return 1;
}
int DestoryStack( SqStack &s )
{   free( s.base );
  s.base = s.top = NULL;
  s.stacksize = 0;
return 1;
}
int ClearStack( SqStack &s )
{   s.top = s.base;
return 1;
}
int StackEmpty( SqStack s )
{   if (s.base == s.top )
  return 1;
  else
  return 0; 
}
int StackLength( SqStack s )
{
return s.top - s.base;
}
int StackTraverse( SqStack s )
{   char *p = s.base;
  while ( p != s.top )
printf( "%c", *p++ );
return 1;
}
int GetTop( SqStack s, char &e )
{   
if ( s.top == s.base )
  return 0; 
  else {       
  e = *( s.top - 1 );
  return 1;
}
}
int Push( SqStack &s, char e )
{   if ( StackLength( s ) >= s.stacksize ) {
  s.base = ( char * ) realloc( s.base, ( s.stacksize + STACKINCREAMENT )*sizeof( char ) );
  if ( !s.base ) exit( 0 );
  s.top = s.base + s.stacksize; 
  s.stacksize += STACKINCREAMENT;
}
  *s.top++ = e;
return 1;
}
int Pop( SqStack &s, char &e )
{   if ( s.top == s.base )
  return 0;
e = *(--s.top);
return 1;
}
int LineEdit( SqStack &s, char &e )
{ 
InitStack( s );
  char ch = getchar( );
while( ch != EOF ) {
while ( ch !='\n' && ch != EOF ) {
switch( ch ) 
{
case '#': Pop( s, e ); break;
case '@': ClearStack( s ); break;
default:  Push( s, ch );
}
ch = getchar( );
}
StackTraverse( s );
ClearStack( s );
if ( ch != EOF ) ch = getchar( );
}
  DestoryStack( s );
return 1;
}
