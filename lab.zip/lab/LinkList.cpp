﻿/*
*LinkList.cpp
*/
#include <stdio.h>
#include <stdlib.h>
typedef struct LNode{
int data;
struct LNode *next;
}LNode, *LinkList;
int CreateList( LinkList &L, int n );
int ListInsert( LinkList &L, int i, int e );
int ListDelete( LinkList &L, int i, int &e );
int GetElem( LinkList L, int i, int &e );
int Traverse( LinkList L );
int main( ) 
{   LinkList L;
  int e = 0;
CreateList( L, 5 );
ListInsert( L, 1, 0 );
Traverse( L );
GetElem( L, 2, e );
ListDelete( L, 1, e );
Traverse( L );
return 1;
}
int CreateList( LinkList &L, int n ) 
{
  L = ( LinkList ) malloc( sizeof( LNode ) );
L->next = NULL;
LinkList p;
printf( "Enter %d element:\n", n );
for ( int i = n; i > 0; i -- ) {
p = ( LinkList ) malloc( sizeof( LNode ) );
  scanf( "%d", &p->data );
p->next = L->next; L->next = p;
}
printf( "OK\n");
  return 1;
}
int ListInsert(LinkList &L, int i, int e )
{   
LinkList p = L;
int j = 1;
while ( p && j < i ) 
{  p = p->next;
++ j;
}
if ( !p || j > i ) return 0;
  LinkList s =( LinkList ) malloc( sizeof( LNode ) );
  s->data = e;
s->next = p->next; p->next = s;
return 1;
}
int ListDelete(LinkList &L, int i, int &e )
{   
LinkList p = L;
int j = 1;
while ( p->next && j < i ) 
{ p = p->next; 
++ j;
}
if ( !p->next || j > i ) return 0;
  LinkList q = p->next;  p->next = q->next;
e = q->data; free( q );
return 1;
}
int Traverse( LinkList L ) 
{
LinkList p = L->next;
printf( "The element in the List: \n");
while( p != NULL ) 
{ printf( "%d ",p->data );
p = p->next;
}
printf( "\n" );
return 1;
}
int GetElem( LinkList L, int i, int &e )
{ 
int j = 1;
LinkList p = L->next;
while( p && j < i )
{ p = p->next; 
++ j;
}
if ( !p || j > i )  return 0;
  e = p->data;
return 1; 
}