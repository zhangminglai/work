﻿/*E:example;p:page;I:insert;O:order;
*E1-7(p0012)
*/
#include <stdio.h>
#include <stdlib.h>
typedef char *Triplet;
int InitTriplet ( Triplet &T, char v1, char v2, char v3 );
int DestoryTriplet ( Triplet &T );
int Get ( Triplet T, int i, char &e );
int Put ( Triplet &T, int i, char e );
int Check ( Triplet T );
int IsAscending( Triplet T );
int IsDecending( Triplet T );
int Max( Triplet T, char &e );
int Min( Triplet T, char &e );
int main(  )
{  
Triplet T;
char v1,v2,v3,e;
v1 = 'a';
  v2 = 'b';
  v3 = 'c';
e = 'e';
InitTriplet( T, v1, v2, v3 );
IsAscending( T );
IsDecending( T );
Max( T, e );
Min( T, e );
Get ( T, 1, e );
Put ( T, 1, e );
Check ( T );
DestoryTriplet ( T );
  return 1;   
}
int InitTriplet ( Triplet &T, char v1, char v2, char v3 ) {
T = ( char * ) malloc( 3* sizeof( char ) );
if ( !T ) exit( 0 );
T[0] = v1;  T[1] = v2; T[2] = v3; 
return 1;
}
int DestoryTriplet ( Triplet &T ) {
free( T ); T = NULL;
return 1;
}
int Get ( Triplet T, int i, char &e ) {
if ( i < 1 || i >3 ) return 0;
e = T[i - 1];
return 1;
}
int Put ( Triplet &T, int i, char e ) {
if ( i < 1 || i >3 ) return 0;
T[i - 1] = e;
return 1;
}
int Check ( Triplet T ) {
for ( int i = 0; i < 3; i ++ )
printf( "%c ", T[ i ] );
printf( "\n" );
return 1;
}
int IsAscending( Triplet T ) {
return ( T[0] <= T[1] ) && ( T[1] <= T[2] );
}
int IsDecending( Triplet T ) {
return ( T[0] >= T[1] ) && ( T[1] >= T[2] );
}
int Max( Triplet T, char &e ) {
e = (T[0] >= T[1] )? ((T[0] >= T[2])?  T[0]:T[2]) :
  ((T[1] >= T[2])?  T[1]:T[2]) ;
return 1;
}
int Min( Triplet T, char &e ) {
e = (T[0] <= T[1] )? ((T[0] <= T[2])?  T[0]:T[2]) :
  ((T[1] <= T[2])?  T[1]:T[2]) ;
return 1;
}