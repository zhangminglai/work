﻿/*
*LinkQueue.cpp
*/
#include<stdio.h>
#include<stdlib.h>
#define QElemType int
typedef struct QNode{
QElemType     data;
struct QNode *next;
}QNode, *QueuePtr;
typedef struct {
QueuePtr front;
QueuePtr rear;
}LinkQueue;
int InitQueue( LinkQueue &Q );
int EnQueue( LinkQueue &Q, QElemType e );
int DeQueue( LinkQueue &Q, QElemType &e );
int DestoryQueue( LinkQueue &Q );
int ClearQueue( LinkQueue &Q );
int QueueEmpty( LinkQueue Q );
int GetHead( LinkQueue Q, QElemType &e );
int QueueLength( LinkQueue Q );
int QueueTraverse( LinkQueue Q );
int main( )
{
LinkQueue Q;
QElemType e;
e = 5;
InitQueue( Q );
if ( !QueueEmpty( Q ) )
ClearQueue( Q );
EnQueue( Q, 1 );
EnQueue( Q, 2 );
EnQueue( Q, 3 );
GetHead( Q, e );
EnQueue( Q, e );
QueueTraverse( Q );
e = QueueLength( Q );
EnQueue( Q, e );
QueueTraverse( Q );
DestoryQueue( Q );
return 1;
}
int InitQueue( LinkQueue &Q )
{
Q.front = Q.rear = ( QueuePtr ) malloc ( sizeof( QNode ) );
if ( !Q.front ) exit( 0 );
Q.front->next = NULL;
return 1;
}
int DestoryQueue( LinkQueue &Q )
{   
while ( Q.front )
{
Q.rear = Q.front->next;
free( Q.front );
Q.front = Q.rear;
}
return 1;
}
int ClearQueue( LinkQueue &Q )
{   
QueuePtr p = Q.front->next;
while ( p )
{
Q.rear = p->next ;
free( p );
p = Q.rear;
}
Q.rear = Q.front;
Q.front->next = NULL;
return 1;
}
int QueueEmpty( LinkQueue Q )
{   
if ( Q.rear == Q.front )
return 1;
else
return 0;
}
int GetHead( LinkQueue Q, QElemType &e )
{
e = Q.front->next->data;
return 1;
}
int EnQueue( LinkQueue &Q, QElemType e )
{
QueuePtr p = ( QueuePtr ) malloc ( sizeof( QNode ) );
if ( !p ) exit( 0 );
p->data = e; p->next = NULL;
Q.rear->next = p;
Q.rear = p;
return 1;
}
int DeQueue( LinkQueue &Q, QElemType &e )
{
if ( Q.front == Q.rear ) return 0;
QueuePtr p = Q.front->next;
e = p->data;
Q.front->next = p->next;
if ( p == Q.rear ) // p->next = NULL;
Q.rear = Q.front; 
free( p );
return 1;
}
int QueueTraverse( LinkQueue Q )
{
QueuePtr p = Q.front->next;
while ( p )
{
printf( "%d ", p->data );
p = p->next;
}
printf( "\n" );
return 1;
}
int QueueLength( LinkQueue Q )
{
QueuePtr p = Q.front->next;
int lenth = 0;
while ( p )
{
++ lenth;
p = p->next;
}
return lenth;
}