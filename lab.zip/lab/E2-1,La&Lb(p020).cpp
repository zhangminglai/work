﻿/*E:example;p:page;I:insert;O:order;
*E2-1,La&Lb(p020)
*/
#include <stdio.h>
#include <stdlib.h>
#define LIST_INIT_SIZE 2
#define LIST_INSCREAMENT 5
typedef struct {
int  *elem;
int  length;
int  listsize;
}SqList;
int InitList ( SqList &T );
int DestoryList ( SqList &T );
int ClearList( SqList &T );
bool ListEmpty( SqList T );
int ListInsert( SqList &T, int i, int e );
int ListDelete( SqList &T, int i, int &e );
int NextElem ( SqList T, int cur_e, int &e );
int PriorElem( SqList T, int cur_e, int &e );
int GetElem ( SqList T, int i, int &e );
int LocateElem( SqList T, int e );
int ListLength( SqList T );
int ListTraverse( SqList T );
void Union_List( SqList &La, SqList Lb );
int main(  )
{  
SqList La,Lb;
int e = 0;
InitList( La );
InitList( Lb );
  
  ListInsert( La, 1, 50 );
ListInsert( La, 2, 51 );
ListInsert( La, 3, 52 );
ListInsert( Lb, 1, 53 );
ListInsert( Lb, 2, 51 );
ListInsert( Lb, 3, 55 );
ListTraverse( La );
  ListTraverse( Lb );
  Union_List( La, Lb );
  ListTraverse( La );
  ListTraverse( Lb );
DestoryList( La );
DestoryList( Lb );
return 1;   
}
int InitList ( SqList &T ) {
T.elem = ( int * ) malloc( LIST_INIT_SIZE* sizeof( int ) );
if ( !T.elem ) exit( 0 );
T.length = 0;
  T.listsize = LIST_INIT_SIZE;
return 1;
}
int DestoryList ( SqList &T ) {
free( T.elem ); T.elem = NULL;
  T.length = 0;
  T.listsize = 0;
return 1;
}
int ClearList( SqList &T ) {
T.length = 0;
return 1;
}
bool ListEmpty( SqList T ) {
return !T.length;
}
int ListInsert( SqList &T, int i, int e ) {
if ( i < 1 || i > T.length + 1 )
return 0;
if ( T.length >= T.listsize ) 
{
   int *newbase = ( int * ) realloc( T.elem, (LIST_INIT_SIZE + LIST_INSCREAMENT)* sizeof( int ) );
  if ( !newbase ) exit( 0 );
T.elem = newbase;
  T.listsize += LIST_INSCREAMENT;
}
int *q = &(T.elem[ i - 1 ]);
  
   for ( int* p = &(T.elem[ T.length - 1 ]); p >= q; p -- )
  *(p + 1) = *p;
  *q = e;
++ T.length;
  return 1;
}
int ListDelete( SqList &T, int i, int &e ) {
if ( i < 1 || i > T.length )
return 0;
int *q = &(T.elem[ i - 1 ]);
e = *q;
  for ( int *p = q; p < &(T.elem[T.length - 1]); p ++ )
  *p = *(p + 1);
-- T.length;
  return 1;
}
int NextElem ( SqList T, int cur_e, int &e ) {
   for ( int i = 0; i < T.length - 1; i ++ )
  if ( cur_e == T.elem[ i ] )
{
  e = T.elem[ i + 1 ];
  return 1;
}
return 0;  
}
int PriorElem( SqList T, int cur_e, int &e ) {
   for ( int i = 1; i < T.length; i ++ )
  if ( cur_e == T.elem[ i ] )
{
  e = T.elem[ i - 1 ];
  return 1;
}
return 0;
}
int GetElem ( SqList T, int i, int &e ) {
if ( i < 1 || i > T.length )
return 0;
  e = T.elem[ i - 1 ];
  return 1;
}
int LocateElem( SqList T, int e ) {
for ( int i = 0; i < T.length; i ++ )
if ( e == T.elem[ i ] )
{
//printf( "It's in %d \n", i + 1 );
  return 1;
}
  return 0;
}
int ListLength( SqList T ) {
return T.length;
}
int ListTraverse( SqList T ) {
for ( int i = 0; i < T.length; i ++ )
printf( "%d ", T.elem[ i ] );
printf( "\n" );
return 1;
}
void Union_List( SqList &La, SqList Lb ) {
  int La_len = La.length;
int Lb_len = Lb.length;
int e = 0;
for ( int i = 1; i <= Lb_len; i ++ ) {
GetElem( Lb, i, e );
  if ( !LocateElem( La, e ) )
  ListInsert( La, ++ La_len, e );
}
}

