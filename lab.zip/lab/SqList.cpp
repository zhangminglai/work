﻿/*
*[SqList.cpp]ADT List{021-026}
*/
#include <stdio.h>
#include <stdlib.h>
#define LIST_INIT_SIZE   5
#define LIST_INSCREAMENT 5
#define LElemType      int
typedef struct {
LElemType *elem;
int      length;
int    listsize;
}SqList;
int InitList( SqList &L );
int DestoryList( SqList &L );
int ClearList( SqList &L );
bool ListEmpty( SqList L );
int ListInsert( SqList &L, int i, LElemType e );
int ListDelete( SqList &L, int i, LElemType &e );
int NextElem( SqList L, LElemType cur_e, LElemType &e );
int PriorElem( SqList L, LElemType cur_e, LElemType &e );
int GetElem( SqList L, int i, LElemType &e );
int LocateElem( SqList L, LElemType e );
int ListLength( SqList L );
int ListTraverse( SqList L );
// Testing Function
int check( int n, LElemType e );
int main(  )
{  
SqList L;
LElemType e = 0;
InitList( L );
check( 0, e );
if ( !ListEmpty( L ) )
ClearList( L );
  ListInsert( L, 1, 0 );
ListInsert( L, 2, 1 );
ListInsert( L, 3, 2 );
ListInsert( L, 4, 3 );
ListInsert( L, 5, 4 );
ListInsert( L, 6, 5 );
ListInsert( L, 7, 6 );
  ListTraverse( L );
ListDelete( L, 7, e );
check( 1, e );
PriorElem( L, 1, e );
check( 2, e );
  NextElem ( L, 0, e );
check( 3, e );
  GetElem ( L, 3, e );
check( 4, e );
  check( 5, LocateElem( L, e ) );
check( 6, ListLength( L ) );
DestoryList( L );
return 1;   
}
int InitList( SqList &L ) 
{
L.elem = ( LElemType * )malloc( LIST_INIT_SIZE* sizeof( LElemType ) );
if ( !L.elem ) exit( 0 );
L.length = 0;
  L.listsize = LIST_INIT_SIZE;
return 1;
}
int DestoryList( SqList &L ) 
{
free( L.elem ); 
L.elem = NULL;
  L.length = 0;
  L.listsize = 0;
return 1;
}
int ClearList( SqList &L ) 
{
L.length = 0;
return 1;
}
bool ListEmpty( SqList L ) 
{
return !L.length;
}
int ListInsert( SqList &L, int i, LElemType e ) 
{ // i->L.length位置元素从L.length依次后移，在L中第i个位置处插入新元素
if ( i < 1 || i > L.length + 1 )
return 0;
if ( L.length >= L.listsize ) 
{
   LElemType *newbase = ( LElemType * )realloc( L.elem, (LIST_INIT_SIZE + LIST_INSCREAMENT)*sizeof( LElemType ) );
  if ( !newbase ) exit( 0 );
L.elem = newbase;
  L.listsize += LIST_INSCREAMENT;
}
LElemType *q = &(L.elem[ i - 1 ]);
   for ( LElemType* p = &(L.elem[ L.length - 1 ]); p >= q; p -- )
  *(p + 1) = *p;
  *q = e;
++ L.length;
  return 1;
}
int ListDelete( SqList &L, int i, LElemType &e ) 
{ // 在L中第i个位置处删除该元素，i+1->L.length位置元素从i+1依次前移
if ( i < 1 || i > L.length )
return 0;
LElemType *q = &(L.elem[ i - 1 ]);
e = *q;
for ( LElemType *p = q; p < &(L.elem[L.length - 1]); p ++ )
*p = *(p + 1);
-- L.length;
return 1;
}
int NextElem( SqList L, LElemType cur_e, LElemType &e ) 
{
   for ( int i = 0; i < L.length - 1; i ++ )
  if ( cur_e == L.elem[ i ] )
{
  e = L.elem[ i + 1 ];
  return 1;
}
return 0;  
}
int PriorElem( SqList L, LElemType cur_e, LElemType &e ) 
{
   for ( LElemType i = 1; i < L.length; i ++ )
  if ( cur_e == L.elem[ i ] )
{
  e = L.elem[ i - 1 ];
  return 1;
}
return 0;
}
int GetElem( SqList L, int i, LElemType &e ) {
if ( i < 1 || i > L.length )
return 0;
  e = L.elem[ i - 1 ];
  return 1;
}
int LocateElem( SqList L, LElemType e ) {
for ( int i = 0; i < L.length; i ++ )
if ( e == L.elem[ i ] )
{
return i + 1;
}
  return 0;
}
int ListLength( SqList L ) {
return L.length;
}
int ListTraverse( SqList L ) {
for ( int i = 0; i < L.length; i ++ )
printf( "%d ", L.elem[ i ] );
printf( "\n" );
return 1;
}
// Testing Function
int check( int n, LElemType e )
{   
  printf( "check[%d]:%d\n", n, e );
return 1;
}