﻿/*
*[BinaryTree.cpp]ADT BinaryTree{121-123}
*/
#include <stdio.h>
#include <stdlib.h>
#define        TElemType char
typedef struct BiTNode{
  TElemType  data;
  struct BiTNode *lchild, *rchild;
}BiTNode, *BiTree;
int InitBiTree( BiTree &T );
int CreateBiTree( BiTree &T );
int DestoryBiTree( BiTree &T );
int PreOrderTraverse( BiTree T );
int InOrderTraverse( BiTree T );
int PostOrderTraverse( BiTree T );
int main( )
{   
  BiTree T;
  CreateBiTree( T );
  PreOrderTraverse( T );
  putchar( 10 );
  InOrderTraverse( T );
  putchar( 10 );
  PostOrderTraverse( T );
  putchar( 10 );
  DestoryBiTree( T );
  return 1;
}
int InitBiTree( BiTree &T )
{
  T = NULL;
  return 1;
}
int CreateBiTree( BiTree &T )
{
  TElemType ch;
  // int h;
  // {-+a  *b  -c  d  /e  f  }
  scanf( "%c", &ch );
  // h = getchar( ); // Receive char ENTER
  if( ch == ' ' ) T = NULL;
  else 
  {
  T = ( BiTNode* ) malloc( sizeof( BiTNode ) );
  if ( !T ) exit( 0 );
  T->data = ch;
  CreateBiTree( T->lchild );
  CreateBiTree( T->rchild );
  }
  return 1;
}
int DestoryBiTree( BiTree &T )
{
  if ( T ) // subTree is not NULL 
  {
  while ( T->lchild != NULL ||  T->rchild != NULL  )
  {
  DestoryBiTree(T->lchild );
  DestoryBiTree(T->rchild );
  }
  if ( T->lchild == NULL && T->rchild == NULL )
  {
  free( T );
  T = NULL;
  }
  }
  return 1;
}
int PreOrderTraverse( BiTree T )
{
  if ( T )
  {
  printf( "%c", T->data );
  PreOrderTraverse( T->lchild );
  PreOrderTraverse( T->rchild );
  }
  return 1;
}
int InOrderTraverse( BiTree T )
{
  if ( T )
  {
  InOrderTraverse( T->lchild );
  printf( "%c", T->data );
  InOrderTraverse( T->rchild );
  }
  return 1;
}
int PostOrderTraverse( BiTree T )
{
  if ( T )
  {
  PostOrderTraverse( T->lchild );
  PostOrderTraverse( T->rchild );
  printf( "%c", T->data );
  }
  return 1;
}