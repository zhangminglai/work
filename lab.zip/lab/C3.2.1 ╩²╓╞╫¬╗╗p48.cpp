﻿#include <stdio.h>
#include <stdlib.h>
#define STACK_INIT_SIZE 5
#define STACKINCREAMENT 5
typedef struct {
int *base;
int *top;
int stacksize;
}SqStack;
int InitStack( SqStack &s );
int DestoryStack( SqStack &s );
int ClearStack( SqStack &s );
int StackEmpty( SqStack s );
int StackLength( SqStack s );
int StackTraverse( SqStack s );
int GetTop( SqStack s, int &e );
int Push( SqStack &s, int e );
int Pop( SqStack &s, int &e );
int conversion( SqStack &s, int &e );
int main( )
{   
SqStack s;
int e = 0;
  conversion( s, e );
  DestoryStack( s );
return 1;
}
int InitStack( SqStack &s )
{   s.base = ( int * )malloc( STACK_INIT_SIZE*sizeof( int ) );
  if ( !s.base ) exit( 0 );
else
s.top = s.base;
s.stacksize = STACK_INIT_SIZE;
return 1;
}
int DestoryStack( SqStack &s )
{   free( s.base );
  s.base = s.top = NULL;
  s.stacksize = 0;
return 1;
}
int ClearStack( SqStack &s )
{   s.top = s.base;
return 1;
}
int StackEmpty( SqStack s )
{   if (s.base == s.top )
  return 1;
  else
  return 0; 
}
int StackLength( SqStack s )
{
return s.top - s.base;
}
int StackTraverse( SqStack s )
{   int *p = s.base;
  while ( p != s.top )
printf( "%d ", *p++ );
printf( "\n" );
return 1;
}
int GetTop( SqStack s, int &e )
{   
if ( s.top == s.base )
  return 0; 
  else {       
  e = *( s.top - 1 );
  return 1;
}
}
int Push( SqStack &s, int e )
{   if ( StackLength( s ) >= s.stacksize ) {
  s.base = ( int * ) realloc( s.base, ( s.stacksize + STACKINCREAMENT )*sizeof( int ) );
  if ( !s.base ) exit( 0 );
  s.top = s.base + s.stacksize; 
  s.stacksize += STACKINCREAMENT;
}
  *s.top++ = e;
return 1;
}
int Pop( SqStack &s, int &e )
{   if ( s.top == s.base )
  return 0;
e = *(--s.top);
return 1;
}
int conversion( SqStack &s, int &e )
{ 
int N = 0;
InitStack( s );
scanf( "%d", &N );
while( N )
{
Push( s, N%8 );
N = N/8;
}
while( !StackEmpty( s ) )
{
Pop( s, e );
  printf( "%d", e );
}
return 1;
}