﻿/*
*Process.cpp
*/
#include <stdio.h>
#include <time.h>
int Process_A( int t );
int Process_B( int t );
int switch_AB( int t );
int main( )
{  
int t = 0;
switch_AB( t );
return 1;
}
int switch_AB( int t )
{   int w = t % 2;
while ( t < 100000 ) {
switch( w )
{
case 0: Process_A( 1 ); w = 1; break;
case 1: Process_B( 1 ); w = 0; break;
}
t ++;
}
  printf( "\n" );
return 1;
}
int Process_A( int t )
{  
  while ( t )
{
printf( "A" );
t --;
}
return 1;
}
int Process_B( int t )
{  
  while ( t ) 
{
printf( "B" );
t --;
}
return 1;
}
