﻿#include<iostream>
#define NUM 10
using namespace std;
int Print(int *list,int n);
int DirectInsert(int *list,int n);
int main()
{
  i = sizeof(arr)/sizeof(int);  // The mount of element in the array
int arr[NUM];
  int i;
  srand(1); //初始化随机数发生器
  for( i = 0; i < NUM; i ++ )
{
    arr[i] = rand() % 100;//随机数在0到99范围内
}
  cout << "before sorted :" << endl;
  Print( arr, i ); // print
  DirectInsert( arr, i );  // sorting
  cout << "after sorted :" << endl;
  Print( arr, i ); // print
  return 0;
} 
int Print(int *list,int n)
{
int i;
for (i=0;i<n;i++)
    cout << list[i] << ".";
  cout << endl;
return 1;
}
int DirectInsert(int *list,int n)
{   //
int i, j, x;
  for ( i = 1; i < n; i ++ )
{
    x = list[ i ];  // contempoary store
    for ( j = i - 1; j >= 0; j -- )
{
    if (list[ j ] > x)
  {
    list[ j + 1] = list[ j ];
  }
  else
    break;
}
    list[ j + 1 ] = x;
}
  return 1;
}