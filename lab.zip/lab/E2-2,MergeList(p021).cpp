﻿/*E:example;p:page;I:insert;O:order;
*E2-2,MergeList(p021)
*/
#include <stdio.h>
#include <stdlib.h>
#define LIST_INIT_SIZE 15
#define LIST_INSCREAMENT 5
typedef struct {
int  *elem;
int  length;
int  listsize;
}SqList;
int InitList ( SqList &T );
int DestoryList ( SqList &T );
int ClearList( SqList &T );
bool ListEmpty( SqList T );
int ListInsert( SqList &T, int i, int e );
int ListDelete( SqList &T, int i, int &e );
int NextElem ( SqList T, int cur_e, int &e );
int PriorElem( SqList T, int cur_e, int &e );
int GetElem ( SqList T, int i, int &e );
int LocateElem( SqList T, int e );
int ListLength( SqList T );
int ListTraverse( SqList T );
void MergeList( SqList La,SqList Lb,SqList &Lc );
int main(  )
{  
SqList La,Lb,Lc;
InitList( La );
InitList( Lb );
InitList( Lc );
  ListInsert( La, 1, 50 );
ListInsert( La, 2, 51 );
ListInsert( La, 3, 52 );
ListInsert( Lb, 1, 49 );
ListInsert( Lb, 2, 52 );
ListInsert( Lb, 3, 59 );
ListTraverse( La );
  ListTraverse( Lb );
ListTraverse( Lc );
  MergeList( La, Lb, Lc );
  ListTraverse( Lc );
DestoryList( La );
DestoryList( Lb );
DestoryList( Lc );
return 1;   
}
int InitList ( SqList &T ) {
T.elem = ( int * ) malloc( LIST_INIT_SIZE* sizeof( int ) );
if ( !T.elem ) exit( 0 );
T.length = 0;
  T.listsize = LIST_INIT_SIZE;
return 1;
}
int DestoryList ( SqList &T ) {
free( T.elem ); T.elem = NULL;
  T.length = 0;
  T.listsize = 0;
return 1;
}
int ClearList( SqList &T ) {
T.length = 0;
return 1;
}
bool ListEmpty( SqList T ) {
return !T.length;
}
int ListInsert( SqList &T, int i, int e ) {
if ( i < 1 || i > T.length + 1 )
return 0;
if ( T.length >= T.listsize ) 
{
   int *newbase = ( int * ) realloc( T.elem, (LIST_INIT_SIZE + LIST_INSCREAMENT)* sizeof( int ) );
  if ( !newbase ) exit( 0 );
T.elem = newbase;
  T.listsize += LIST_INSCREAMENT;
}
int *q = &(T.elem[ i - 1 ]);
  
   for ( int* p = &(T.elem[ T.length - 1 ]); p >= q; p -- )
  *(p + 1) = *p;
  *q = e;
++ T.length;
  return 1;
}
int ListDelete( SqList &T, int i, int &e ) {
if ( i < 1 || i > T.length )
return 0;
int *q = &(T.elem[ i - 1 ]);
e = *q;
  for ( int *p = q; p < &(T.elem[T.length - 1]); p ++ )
  *p = *(p + 1);
-- T.length;
  return 1;
}
int NextElem ( SqList T, int cur_e, int &e ) {
   for ( int i = 0; i < T.length - 1; i ++ )
  if ( cur_e == T.elem[ i ] )
{
  e = T.elem[ i + 1 ];
  return 1;
}
return 0;  
}
int PriorElem( SqList T, int cur_e, int &e ) {
   for ( int i = 1; i < T.length; i ++ )
  if ( cur_e == T.elem[ i ] )
{
  e = T.elem[ i - 1 ];
  return 1;
}
return 0;
}
int GetElem ( SqList T, int i, int &e ) {
if ( i < 1 || i > T.length )
return 0;
  e = T.elem[ i - 1 ];
  return 1;
}
int LocateElem( SqList T, int e ) {
for ( int i = 0; i < T.length; i ++ )
if ( e == T.elem[ i ] )
{
printf( "%d ", i + 1 );
  return 1;
}
  return 0;
}
int ListLength( SqList T ) {
return T.length;
}
int ListTraverse( SqList T ) {
for ( int i = 0; i < T.length; i ++ )
printf( "%d ", T.elem[ i ] );
printf( "\n" );
return 1;
}
void MergeList( SqList La,SqList Lb,SqList &Lc ) {
int *p = La.elem;
int *q = Lb.elem;

for ( int i = 1; i <= La.length + Lb.length; i ++ )
{
  if ( p <= La.elem + La.length - 1 && q <= Lb.elem + Lb.length - 1 )
{
if ( *p <= *q ) {
  ListInsert( Lc, i, *p );
  p ++;
}
  else {
  ListInsert( Lc, i, *q );
  q ++;
}
}
if ( p <= La.elem + La.length - 1 )
{      
  ListInsert( Lc, i, *p );
  p ++;
}
   if ( q <= Lb.elem + Lb.length - 1 )
{
  ListInsert( Lc, i, *q );
  q ++;
}
}
printf( "%d\n", Lc.length );
  printf( "%d\n",i );
}
/*
void MergeList( SqList La,SqList Lb,SqList &Lc ) {
int *p = La.elem;
int *q = Lb.elem;
int i = 1;
  while ( p <= La.elem + La.length - 1 && q <= Lb.elem + Lb.length - 1 )
{
if ( *p <= *q ) {
  ListInsert( Lc, i ++, *p );
  p ++;
}
  else {
  ListInsert( Lc, i ++, *q );
  q ++;
}
}
while ( p <= La.elem + La.length - 1 )
{      
  ListInsert( Lc, i ++, *p );
  p ++;
}
   while ( q <= Lb.elem + Lb.length - 1 )
{
  ListInsert( Lc, i ++, *q );
  q ++;
}
printf( "%d\n", Lc.length );
  printf( "%d\n",i );
}
*/