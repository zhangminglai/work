﻿/*
*Maze.cpp
*/
#include <stdio.h>
#include <stdlib.h>
#define STACK_INIT_SIZE 5
#define STACKINCREAMENT 5
typedef struct {
int x;
int y;
}PosType;
typedef struct {
int order;
PosType seat;
int direction;
}SElemType;
typedef struct {
SElemType *base;
SElemType *top;
int stacksize;
}SqStack;
typedef int MazeType[10][10];
int InitStack( SqStack &s );
int DestoryStack( SqStack &s );
int ClearStack( SqStack &s );
bool StackEmpty( SqStack s );
int StackLength( SqStack s );
int StackTraverse( SqStack s );
int GetTop( SqStack s, SElemType &e );
int Push( SqStack &s, SElemType e );
int Pop( SqStack &s, SElemType &e );
int MazePath( SqStack &s, MazeType &maze, PosType start, PosType end );
int DisplayMaze( MazeType maze );
bool Pass( MazeType maze, PosType curpos );
int FootPrint( MazeType &maze, PosType curpos );
int NextPos( PosType &curpos, PosType next, int direction );
int MarkPrint( MazeType &maze, PosType seat );
int PrePos(  PosType &curpos, PosType previous, int direction );
int DisplayEI( SElemType e );
int main( )
{   
PosType start;
start.x=1;start.y=1;
PosType end;
end.x=8; end.y=8;
MazeType maze = {
{0,0,0,0,0,0,0,0,0,0},
{0,1,1,0,1,1,1,0,1,0},
{0,1,1,0,1,1,1,0,1,0},
{0,1,1,1,1,0,0,1,1,0},
{0,1,0,0,0,1,1,1,1,0},
{0,1,1,1,0,1,1,1,1,0},
{0,1,0,1,1,1,0,1,1,0},
{0,1,0,0,0,1,0,0,1,0},
{0,0,0,1,1,1,1,1,1,0},
{0,0,0,0,0,0,0,0,0,0}
};
DisplayMaze( maze );
SqStack s;
InitStack( s );
MazePath( s, maze, start, end );
StackTraverse( s );
DestoryStack( s );
return 1;
}
int InitStack( SqStack &s )
{   s.base = ( SElemType * )malloc( STACK_INIT_SIZE*sizeof( SElemType ) );
  if ( !s.base ) exit( 0 );
else {
  s.top = s.base;
  s.stacksize = STACK_INIT_SIZE;
  return 1;
}
}
int DestoryStack( SqStack &s )
{   
free( s.base );
  s.base = s.top = NULL;
  s.stacksize = 0;
  return 1;
}
bool StackEmpty( SqStack s )
{   if (s.base == s.top )
  return 1;
  else
  return 0; 
}
int StackLength( SqStack s )
{
  return s.top - s.base;
}
int StackTraverse( SqStack s )
{   SElemType *p = s.base;
  while ( p != s.top ) {
  DisplayEI( *p );
  p ++;
}
  return 1;
}
int GetTop( SqStack s, SElemType &e )
{   
if ( s.top == s.base )
  return 0; 
  else {      
SElemType *p;
p = s.top - 1;
  e.direction = p ->direction;
  e.order = p ->order;
e.seat.x = p ->seat.x;
  e.seat.y = p ->seat.y;
  return 1;
}
}
int Push( SqStack &s, SElemType e )
{   
if ( StackLength( s ) >= s.stacksize ) 
{
  s.base = ( SElemType * ) realloc( s.base, ( s.stacksize + STACKINCREAMENT )*sizeof( SElemType ) );
  if ( !s.base )  exit( 0 );
  s.top = s.base + s.stacksize; 
  s.stacksize += STACKINCREAMENT;
}
  s.top->direction = e.direction;
  s.top->order = e.order;
s.top->seat.x = e.seat.x;
  s.top->seat.y = e.seat.y;
s.top++;
  return 1;
}
int Pop( SqStack &s, SElemType &e )
{   
if ( s.top == s.base )
  return 0;
  --s.top;
  e.direction = s.top->direction;
  e.order = s.top->order;
  e.seat.x = s.top->seat.x;
  e.seat.y = s.top->seat.y;
  return 1;
}
int MazePath( SqStack &s, MazeType &maze, PosType start, PosType end )
{   
  PosType curpos = start;
  SElemType e;
int curstep = 1;
do {
// 能通过吗？
if ( Pass( maze, curpos ) )  {   // 是
  FootPrint( maze, curpos );  // 留下脚印 1->2

e.order = curstep;               // 当前的步数
e.seat.x = curpos.x;
e.seat.y = curpos.y;             // 当前坐标赋予元素e
e.direction = 1;                 // 搜索方向为向右
// 将可通的坐标位置，当前的步数，以及下一搜索方位记录在栈
  if ( Push( s, e ) )              
  {    printf( "入栈：" );
  DisplayEI( e );
  curstep ++;                   // 步数自增
  }
  // 当前的坐标，是否到达出口地址
  if ( curpos.x == end.x && curpos.y == end.y ) 
  return 1;                 // 是，则返回值
  NextPos( curpos, curpos, 1 ); // 否，继续探索
} // if 
  else {                           // 否 
  if ( !StackEmpty( s ) ) {
  if ( Pop( s, e ) )
{    
printf( "出栈：" );
  DisplayEI( e );
curstep --;
}
  
  if ( e.direction < 4 && e.direction >= 1) {
  e.direction ++; 
  if ( Push( s, e ) )
{    
printf( "入栈：" );
  DisplayEI( e );
curstep ++;
}
  NextPos( curpos, e.seat, e.direction );
} // if 
    while ( e.direction == 4 && !StackEmpty( s ) ) {
  MarkPrint( maze, e.seat ); 
  if ( Pop( s, e ) ) 
  {
  printf( "出栈：" );
  DisplayEI( e );
  curstep --;
  }
  GetTop( s, e );
  curpos.x = e.seat.x;
  curpos.y = e.seat.y;
} // while
  } // if 
} // else
}while ( !StackEmpty( s ) );
return 0;
}
bool Pass( MazeType maze, PosType curpos )
{
if ( maze[curpos.x][curpos.y] == 1 )
return 1;
else
return 0;
}
int FootPrint( MazeType &maze, PosType curpos )
{
if ( maze[curpos.x][curpos.y] == 1 )
  maze[curpos.x][curpos.y] = 2;
return 1;
}
int NextPos( PosType &curpos, PosType next, int direction )
{   
if ( direction >=1 && direction <= 4 ) 
{
  switch ( direction )
{
case 1: next.y ++; break; //east
case 2: next.x ++; break; //south
case 3: next.y --; break; //west
case 4: next.x --; break; //north
}
curpos.x = next.x;
curpos.y = next.y;
return 1;
}
  return 0;
}
int PrePos(  PosType &curpos, PosType previous, int direction )
{   
if ( direction >=1 && direction <= 4 ) 
{
  switch ( direction )
{
case 1: previous.y --; break; //east
case 2: previous.x --; break; //south
case 3: previous.y ++; break; //west
case 4: previous.x ++; break; //north
}
curpos.x = previous.x;
curpos.y = previous.y;
return 1;
}
  return 0;
}
int MarkPrint( MazeType &maze, PosType seat ) 
{ 
  maze[seat.x][seat.y] = 0;
return 1;
}
int DisplayMaze( MazeType maze )
{   
for ( int i = 0; i < 10; i ++ )
for ( int j = 0; j < 10; j ++ ) {
if ( j % 10 == 0 )
  printf("\n");
//printf( "%d ", maze[i][j]);
  if ( maze[i][j] )
  printf( "□");
  else
  printf( "■");
}
printf("\n");
return 1;
}
int DisplayEI( SElemType e )
{
printf( "Step:%2d[%2d,%2d]:", e.order, e.seat.x, e.seat.y );
  switch( e.direction )
{
case 1: printf("[East ]");break;
case 2: printf("[South]");break;
case 3: printf("[West ]");break;
case 4: printf("[North]");break;
default:
  printf( "Uknow direction" );
}
printf( "\n" );
return 1;
}