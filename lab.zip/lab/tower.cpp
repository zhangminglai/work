﻿/*
*tower.cpp
*/
#include <stdio.h>
#include <stdlib.h>
#define STACK_INIT_SIZE 5
#define STACKINCREAMENT 5
typedef struct {
int n;
char x,y,z;
}SElemType;
typedef struct {
SElemType *base;
SElemType *top;
int stacksize;
}SqStack;
int InitStack( SqStack &s );
int DestoryStack( SqStack &s );
int ClearStack( SqStack &s );
bool StackEmpty( SqStack s );
int StackLength( SqStack s );
int StackTraverse( SqStack s );
int GetTop( SqStack s, SElemType &e );
int Push( SqStack &s, SElemType e );
int Pop( SqStack &s, SElemType &e );
int DisplayEI( SElemType e );
int Move( int &c, char x, int n, char z );
int tower( SqStack &s, int n, char x, char y, char z );
int main( )
{   
SqStack s;
InitStack( s );
tower( s, 4, 'X', 'Y', 'Z' );
DestoryStack( s );
return 1;
}
int InitStack( SqStack &s )
{   s.base = ( SElemType * )malloc( STACK_INIT_SIZE*sizeof( SElemType ) );
  if ( !s.base ) exit( 0 );
else {
  s.top = s.base;
  s.stacksize = STACK_INIT_SIZE;
  return 1;
}
}
int DestoryStack( SqStack &s )
{   
free( s.base );
  s.base = s.top = NULL;
  s.stacksize = 0;
  return 1;
}
bool StackEmpty( SqStack s )
{   if ( s.base == s.top )
  return 1;
  else
  return 0; 
}
int StackLength( SqStack s )
{
  return s.top - s.base;
}
int StackTraverse( SqStack s )
{   SElemType *p = s.base;
  while ( p != s.top ) {
  DisplayEI( *p );
  p ++;
}
  return 1;
}
int GetTop( SqStack s, SElemType &e )
{   
if ( s.top == s.base )
  return 0; 
  else {      
SElemType *p;
p = s.top - 1;
  e.n  = p ->n;
e.x = p ->x;
  e.y = p ->y;
  e.z = p ->z;
  return 1;
}
}
int Push( SqStack &s, SElemType e )
{   
if ( StackLength( s ) >= s.stacksize ) 
{
  s.base = ( SElemType * ) realloc( s.base, ( s.stacksize + STACKINCREAMENT )*sizeof( SElemType ) );
  if ( !s.base )  exit( 0 );
  s.top = s.base + s.stacksize; 
  s.stacksize += STACKINCREAMENT;
}
  s.top->n = e.n;
s.top->x = e.x;
  s.top->y = e.y;
  s.top->z = e.z;
s.top++;
  return 1;
}
int Pop( SqStack &s, SElemType &e )
{   
if ( s.top == s.base )
  return 0;
  --s.top;
  e.n = s.top->n;
  e.x = s.top->x;
  e.y = s.top->y;
e.z = s.top->z;
  return 1;
}
int DisplayEI( SElemType e )
{
printf( "qusetion:%2d[%c,%c,%c]\n", e.n, e.x, e.y, e.z );
return 1;
}
int tower( SqStack &s, int n, char x, char y, char z )
{   int c = 0;
  SElemType e;
  char temp;
  e.n = n;
  e.x = x;
e.y = y;
e.z = z;
while ( !StackEmpty( s ) || e.n > 0 ) {
if ( e.n > 0 ) {
Push( s, e );
e.n --;
temp = e.y;
e.y = e.z;
e.z = temp;
  }
else {
  Pop( s, e );
  Move( c, e.x, e.n , e.z );
  e.n --;
  temp = e.x;
  e.x = e.y;
  e.y = temp;
}
}
return 1;
}
int Move( int &c, char x, int n, char z )
{
printf( " %5i.Move disk %i form %c to %c\n", ++c,n,x,z );
return 1;
}