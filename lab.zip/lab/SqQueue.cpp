﻿/*
*SqQueue.cpp
*/
#include<stdio.h>
#include<stdlib.h>
#define QElemType int
#define MAXQSIZE 10
typedef struct {
QElemType *base;
int front;
int  rear;
}SqQueue;
int InitQueue( SqQueue &Q );
int ClearQueue( SqQueue &Q );
int QueueEmpty( SqQueue Q );
int EnQueue( SqQueue &Q, QElemType e );
int DeQueue( SqQueue &Q, QElemType &e );
int GetHead( SqQueue Q, QElemType &e );
int QueueLength( SqQueue Q );
int QueueTraverse( SqQueue Q );
int DestoryQueue( SqQueue &Q );
int main( )
{
SqQueue Q;
QElemType e;
InitQueue( Q );
if ( !QueueEmpty( Q ) )
ClearQueue( Q );
EnQueue( Q, 1 );
EnQueue( Q, 2 );
EnQueue( Q, 3 );
GetHead( Q, e );
EnQueue( Q, e );
QueueTraverse( Q );
e = QueueLength( Q );
EnQueue( Q, e );
QueueTraverse( Q );
DestoryQueue( Q );
return 1;
}
int InitQueue( SqQueue &Q )
{
 Q.base = ( QElemType * ) malloc( MAXQSIZE * sizeof( QElemType ) );
if ( !Q.base ) exit( 0 );
Q.front = Q.rear = 0;
return 1;
}
int EnQueue( SqQueue &Q, QElemType e )
{
 if ( ( Q.rear + 1 ) % MAXQSIZE == Q.front ) return 0;
Q.base[ Q.rear ] = e;
++ Q.rear %= MAXQSIZE ;
return 1;
}
int DeQueue( SqQueue &Q, QElemType &e )
{
if ( Q.rear == Q.front ) return 0;
e = Q.base[ Q.front ];
++ Q.front %= MAXQSIZE;
return 1;
}
int DestoryQueue( SqQueue &Q )
{
free( Q.base );
Q.front = Q.rear = 0;
return 1;
}
int ClearQueue( SqQueue &Q )
{
Q.front = Q.rear = 0;
return 1;
}
int QueueEmpty( SqQueue Q )
{
if ( Q.front == Q.rear )
  return 1;
else
return 0;
}
int GetHead( SqQueue Q, QElemType &e )
{
 e = Q.base[ Q.front ];
return 1;
}
int QueueLength( SqQueue Q )
{
return ( Q.rear - Q.front + MAXQSIZE ) % MAXQSIZE;
}
int QueueTraverse( SqQueue Q )
{
for ( int i = Q.front; i < Q.rear; i ++ )
printf( "%d ", Q.base[ i ] );
printf( "\n" );
return 1;
}