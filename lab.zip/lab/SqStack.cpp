﻿/*
*[SqStack.cpp]ADT Stack{044-047}
*/
#include  <stdio.h>
#include <stdlib.h>
#define STACK_INIT_SIZE 5
#define STACKINCREAMENT 5
#define SElemType     int
typedef struct {
SElemType *base;
SElemType  *top;
int   stacksize;
}SqStack;
int InitStack( SqStack &s );
int DestoryStack( SqStack &s );
int ClearStack( SqStack &s );
int StackEmpty( SqStack s );
int StackLength( SqStack s );
int StackTraverse( SqStack s );
int GetTop( SqStack s, SElemType &e );
int Push( SqStack &s, SElemType e );
int Pop( SqStack &s, SElemType &e );
// Testing Function
int check( int n, SElemType e );
int main( )
{   
SqStack s;
SElemType e = 0;
check( 0, e );
  InitStack( s );
if ( !StackEmpty( s ) )
  ClearStack( s );
Push( s, 0 );
Push( s, 1 );
  Push( s, 2 );
Push( s, 3 );
Push( s, 4 );
Push( s, 5 );
Push( s, 6 );
StackTraverse( s );
Pop( s, e );
check( 1, e );
GetTop( s , e );
check( 2, e );
  e = StackLength( s );
  check( 2, e );
  DestoryStack( s );
return 1;
}
int InitStack( SqStack &s )
{  
s.base = ( SElemType * )malloc( STACK_INIT_SIZE*sizeof( SElemType ) );
  if ( !s.base ) exit( 0 );
s.top = s.base;
s.stacksize = STACK_INIT_SIZE;
return 1;
}
int DestoryStack( SqStack &s )
{
free( s.base );
  s.base = s.top = NULL;
  s.stacksize = 0;
return 1;
}
int ClearStack( SqStack &s )
{   
s.top = s.base;
return 1;
}
int StackEmpty( SqStack s )
{   
if (s.base == s.top )
return 1;
  else
  return 0; 
}
int StackLength( SqStack s )
{
return s.top - s.base;
}
int StackTraverse( SqStack s )
{   
SElemType *p = s.base;
  while ( p != s.top )
printf( "%d ", *p++ );
printf( "\n" );
return 1;
}
int GetTop( SqStack s, SElemType &e )
{   
if ( s.top == s.base )
return 0;
else
{       
e = *( s.top - 1 );
return 1;
}
}
int Push( SqStack &s, SElemType e )
{   
if ( StackLength( s ) >= s.stacksize )
{
  s.base = ( SElemType * ) realloc( s.base, ( s.stacksize + STACKINCREAMENT )*sizeof( SElemType ) );
  if ( !s.base ) exit( 0 );
  s.top = s.base + s.stacksize; 
  s.stacksize += STACKINCREAMENT;
}
  *s.top++ = e;
return 1;
}
int Pop( SqStack &s, SElemType &e )
{   
if ( s.top == s.base )
return 0;
e = *(--s.top);
return 1;
}
// Testing Function
int check( int n, SElemType e )
{   
  printf( "check[%d]:%d\n", n, e );
return 1;
}